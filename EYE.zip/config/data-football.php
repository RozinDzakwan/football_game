<?php
    return [
        'template_1' => [
            'email',
            'name',
            'lastname',
            'nickname',
            'age'
        ]
    ]
?>
