<?php $__env->startSection('title'); ?>
    EYE Sport Football League
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container pt-5">
        <div class="content row justify-content-center">
            <div class="col-10 text-center logo">
                <img src="<?php echo e(asset('asset/images/etc/logo_main.png')); ?>" class="logo-main">
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('playgame')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('registration-form', [
                        'data_cookie' => $data_cookie,
                        'all_data_teams' => $data_teams,
                    ])->html();
} elseif ($_instance->childHasBeenRendered('EYjtu9q')) {
    $componentId = $_instance->getRenderedChildComponentId('EYjtu9q');
    $componentTag = $_instance->getRenderedChildComponentTagName('EYjtu9q');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EYjtu9q');
} else {
    $response = \Livewire\Livewire::mount('registration-form', [
                        'data_cookie' => $data_cookie,
                        'all_data_teams' => $data_teams,
                    ]);
    $html = $response->html();
    $_instance->logRenderedChild('EYjtu9q', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('eye_football.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rozin/Documents/UnusualDope/UnusualDope/EYE/resources/views/eye_football/login.blade.php ENDPATH**/ ?>