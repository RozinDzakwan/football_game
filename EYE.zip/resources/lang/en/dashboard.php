<?php
    return array(
        'welcome' => 'Welcome'
    )
?>
